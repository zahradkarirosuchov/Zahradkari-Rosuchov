# Záhradkári Rosuchov

Jednoduchá webová stránka pre záhradkárov v Rosuchove.

## Struktúra priečinkov
Zahradkari-Rosuchov/
├── index.html
├── style.css
├── aktualne/
│   ├── januar2025/
│   │   └── index.html
│   ├── februar2025/
│   │   └── index.html
│   └── marec2025/
│       └── index.html
└── README.md
